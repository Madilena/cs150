#include "Ogre.h"
using namespace std;

int Ogre::getDamage(){
    return 50;
}
