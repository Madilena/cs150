#include "Snake.h"
using namespace std;

int Snake::getDamage(){
    return 10;
}
