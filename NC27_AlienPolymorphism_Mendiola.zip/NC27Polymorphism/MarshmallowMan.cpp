#include "MarshmallowMan.h"
using namespace std;

int MarshmallowMan::getDamage(){
    return 70;
}
